SELECT id, name as building_name, rent_amount, height, status 
FROM buildings
WHERE rent_amount > 5000 AND height > 500
ORDER BY rent_amount DESC, building_name ASC;