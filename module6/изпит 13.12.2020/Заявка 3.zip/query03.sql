SELECT p.id, p.username, pi.first_name, pi.last_name, c.name 
FROM persons p
JOIN companies c ON c.id = p.company_id
JOIN person_info pi ON pi.person_id = p.id
WHERE c.name = 'West'
ORDER BY first_name, last_name;